﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class FormOrder : Form
    {
        public FormOrder()
        {
            InitializeComponent();
        }

        private void order_BindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.order_BindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.online_book_shopDataSet);

        }

        private void FormOrder_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "online_book_shopDataSet.order_". При необходимости она может быть перемещена или удалена.
            this.order_TableAdapter.Fill(this.online_book_shopDataSet.order_);

        }

        private static FormOrder o;
        public static FormOrder fo
        {
            get
            {
                if (o == null || o.IsDisposed) o = new FormOrder();
                return o;
            }
        }
        public void ShowForm()
        {
            Show();
            Activate();
        }
    }
}
