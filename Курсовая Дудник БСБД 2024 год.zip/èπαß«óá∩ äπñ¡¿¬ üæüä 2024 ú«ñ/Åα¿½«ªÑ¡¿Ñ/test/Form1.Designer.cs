﻿namespace test
{
    partial class FormMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMain));
            this.menuStripMain = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.всеКнигиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользователиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.книгаВЗаказеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStripMain = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.файлToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.всеКнигиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.пользователиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.книгаВЗаказеToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.заказToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMain = new System.Windows.Forms.ToolStrip();
            this.выходtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.опрограммеtoolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.книгиtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.пользователиtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.menuStripMain.SuspendLayout();
            this.contextMenuStripMain.SuspendLayout();
            this.toolStripMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStripMain
            // 
            this.menuStripMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.справочникToolStripMenuItem});
            this.menuStripMain.Location = new System.Drawing.Point(0, 0);
            this.menuStripMain.Name = "menuStripMain";
            this.menuStripMain.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStripMain.Size = new System.Drawing.Size(857, 28);
            this.menuStripMain.TabIndex = 0;
            this.menuStripMain.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.файлToolStripMenuItem.Text = "Файл";
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Image = global::test.Properties.Resources.выход;
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Image = global::test.Properties.Resources.инфо;
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(243, 26);
            this.оПрограммеToolStripMenuItem.Text = "О программе...";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // справочникToolStripMenuItem
            // 
            this.справочникToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.всеКнигиToolStripMenuItem,
            this.пользователиToolStripMenuItem,
            this.книгаВЗаказеToolStripMenuItem,
            this.заказToolStripMenuItem});
            this.справочникToolStripMenuItem.Name = "справочникToolStripMenuItem";
            this.справочникToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.справочникToolStripMenuItem.Text = "Справочник";
            // 
            // всеКнигиToolStripMenuItem
            // 
            this.всеКнигиToolStripMenuItem.Image = global::test.Properties.Resources.книги;
            this.всеКнигиToolStripMenuItem.Name = "всеКнигиToolStripMenuItem";
            this.всеКнигиToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.B)));
            this.всеКнигиToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.всеКнигиToolStripMenuItem.Text = "Все книги";
            this.всеКнигиToolStripMenuItem.Click += new System.EventHandler(this.всеКнигиToolStripMenuItem_Click);
            // 
            // пользователиToolStripMenuItem
            // 
            this.пользователиToolStripMenuItem.Image = global::test.Properties.Resources.сотрудники;
            this.пользователиToolStripMenuItem.Name = "пользователиToolStripMenuItem";
            this.пользователиToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.U)));
            this.пользователиToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.пользователиToolStripMenuItem.Text = "Пользователи";
            this.пользователиToolStripMenuItem.Click += new System.EventHandler(this.пользователиToolStripMenuItem_Click);
            // 
            // книгаВЗаказеToolStripMenuItem
            // 
            this.книгаВЗаказеToolStripMenuItem.Image = global::test.Properties.Resources._3771284;
            this.книгаВЗаказеToolStripMenuItem.Name = "книгаВЗаказеToolStripMenuItem";
            this.книгаВЗаказеToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.K)));
            this.книгаВЗаказеToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.книгаВЗаказеToolStripMenuItem.Text = "Книга в заказе";
            this.книгаВЗаказеToolStripMenuItem.Click += new System.EventHandler(this.книгаВЗаказеToolStripMenuItem_Click);
            // 
            // заказToolStripMenuItem
            // 
            this.заказToolStripMenuItem.Image = global::test.Properties.Resources._5218542;
            this.заказToolStripMenuItem.Name = "заказToolStripMenuItem";
            this.заказToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.O)));
            this.заказToolStripMenuItem.Size = new System.Drawing.Size(246, 26);
            this.заказToolStripMenuItem.Text = "Заказ";
            this.заказToolStripMenuItem.Click += new System.EventHandler(this.заказToolStripMenuItem_Click);
            // 
            // contextMenuStripMain
            // 
            this.contextMenuStripMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.contextMenuStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem1,
            this.справочникToolStripMenuItem1});
            this.contextMenuStripMain.Name = "contextMenuStripMain";
            this.contextMenuStripMain.Size = new System.Drawing.Size(164, 52);
            // 
            // файлToolStripMenuItem1
            // 
            this.файлToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem1,
            this.оПрограммеToolStripMenuItem1});
            this.файлToolStripMenuItem1.Name = "файлToolStripMenuItem1";
            this.файлToolStripMenuItem1.Size = new System.Drawing.Size(163, 24);
            this.файлToolStripMenuItem1.Text = "Файл";
            // 
            // выходToolStripMenuItem1
            // 
            this.выходToolStripMenuItem1.Image = global::test.Properties.Resources.выход;
            this.выходToolStripMenuItem1.Name = "выходToolStripMenuItem1";
            this.выходToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.выходToolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.выходToolStripMenuItem1.Text = "Выход";
            this.выходToolStripMenuItem1.Click += new System.EventHandler(this.выходToolStripMenuItem1_Click);
            // 
            // оПрограммеToolStripMenuItem1
            // 
            this.оПрограммеToolStripMenuItem1.Image = global::test.Properties.Resources.инфо;
            this.оПрограммеToolStripMenuItem1.Name = "оПрограммеToolStripMenuItem1";
            this.оПрограммеToolStripMenuItem1.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.I)));
            this.оПрограммеToolStripMenuItem1.Size = new System.Drawing.Size(243, 26);
            this.оПрограммеToolStripMenuItem1.Text = "О программе...";
            this.оПрограммеToolStripMenuItem1.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem1_Click);
            // 
            // справочникToolStripMenuItem1
            // 
            this.справочникToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.всеКнигиToolStripMenuItem1,
            this.пользователиToolStripMenuItem1,
            this.книгаВЗаказеToolStripMenuItem1,
            this.заказToolStripMenuItem1});
            this.справочникToolStripMenuItem1.Name = "справочникToolStripMenuItem1";
            this.справочникToolStripMenuItem1.Size = new System.Drawing.Size(163, 24);
            this.справочникToolStripMenuItem1.Text = "Справочник";
            // 
            // всеКнигиToolStripMenuItem1
            // 
            this.всеКнигиToolStripMenuItem1.Image = global::test.Properties.Resources.книги;
            this.всеКнигиToolStripMenuItem1.Name = "всеКнигиToolStripMenuItem1";
            this.всеКнигиToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.всеКнигиToolStripMenuItem1.Text = "Все книги";
            this.всеКнигиToolStripMenuItem1.Click += new System.EventHandler(this.всеКнигиToolStripMenuItem1_Click);
            // 
            // пользователиToolStripMenuItem1
            // 
            this.пользователиToolStripMenuItem1.Image = global::test.Properties.Resources.сотрудники;
            this.пользователиToolStripMenuItem1.Name = "пользователиToolStripMenuItem1";
            this.пользователиToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.пользователиToolStripMenuItem1.Text = "Пользователи";
            this.пользователиToolStripMenuItem1.Click += new System.EventHandler(this.пользователиToolStripMenuItem1_Click);
            // 
            // книгаВЗаказеToolStripMenuItem1
            // 
            this.книгаВЗаказеToolStripMenuItem1.Image = global::test.Properties.Resources._3771284;
            this.книгаВЗаказеToolStripMenuItem1.Name = "книгаВЗаказеToolStripMenuItem1";
            this.книгаВЗаказеToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.книгаВЗаказеToolStripMenuItem1.Text = "Книга в заказе";
            this.книгаВЗаказеToolStripMenuItem1.Click += new System.EventHandler(this.книгаВЗаказеToolStripMenuItem1_Click);
            // 
            // заказToolStripMenuItem1
            // 
            this.заказToolStripMenuItem1.Image = global::test.Properties.Resources._5218542;
            this.заказToolStripMenuItem1.Name = "заказToolStripMenuItem1";
            this.заказToolStripMenuItem1.Size = new System.Drawing.Size(224, 26);
            this.заказToolStripMenuItem1.Text = "Заказ";
            this.заказToolStripMenuItem1.Click += new System.EventHandler(this.заказToolStripMenuItem1_Click);
            // 
            // toolStripMain
            // 
            this.toolStripMain.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходtoolStripButton,
            this.опрограммеtoolStripButton2,
            this.книгиtoolStripButton,
            this.пользователиtoolStripButton,
            this.toolStripButton1,
            this.toolStripButton2});
            this.toolStripMain.Location = new System.Drawing.Point(0, 28);
            this.toolStripMain.Name = "toolStripMain";
            this.toolStripMain.Size = new System.Drawing.Size(857, 27);
            this.toolStripMain.TabIndex = 2;
            this.toolStripMain.Text = "toolStrip1";
            this.toolStripMain.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStripMain_ItemClicked);
            // 
            // выходtoolStripButton
            // 
            this.выходtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.выходtoolStripButton.Image = global::test.Properties.Resources.выход;
            this.выходtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.выходtoolStripButton.Name = "выходtoolStripButton";
            this.выходtoolStripButton.Size = new System.Drawing.Size(29, 24);
            this.выходtoolStripButton.Text = "Выход";
            this.выходtoolStripButton.Click += new System.EventHandler(this.выходtoolStripButton_Click);
            // 
            // опрограммеtoolStripButton2
            // 
            this.опрограммеtoolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.опрограммеtoolStripButton2.Image = global::test.Properties.Resources.инфо;
            this.опрограммеtoolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.опрограммеtoolStripButton2.Name = "опрограммеtoolStripButton2";
            this.опрограммеtoolStripButton2.Size = new System.Drawing.Size(29, 24);
            this.опрограммеtoolStripButton2.Text = "О программе...";
            this.опрограммеtoolStripButton2.Click += new System.EventHandler(this.опрограммеtoolStripButton2_Click);
            // 
            // книгиtoolStripButton
            // 
            this.книгиtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.книгиtoolStripButton.Image = global::test.Properties.Resources.книги;
            this.книгиtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.книгиtoolStripButton.Name = "книгиtoolStripButton";
            this.книгиtoolStripButton.Size = new System.Drawing.Size(29, 24);
            this.книгиtoolStripButton.Text = "Все книги";
            this.книгиtoolStripButton.Click += new System.EventHandler(this.книгиtoolStripButton_Click);
            // 
            // пользователиtoolStripButton
            // 
            this.пользователиtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.пользователиtoolStripButton.Image = global::test.Properties.Resources.сотрудники;
            this.пользователиtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.пользователиtoolStripButton.Name = "пользователиtoolStripButton";
            this.пользователиtoolStripButton.Size = new System.Drawing.Size(29, 24);
            this.пользователиtoolStripButton.Text = "Пользователи";
            this.пользователиtoolStripButton.Click += new System.EventHandler(this.пользователиtoolStripButton_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::test.Properties.Resources._3771284;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton1.Text = "Книга в заказе";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::test.Properties.Resources._5218542;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton2.Text = "Заказ";
            this.toolStripButton2.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.BackgroundImage = global::test.Properties.Resources._1;
            this.ClientSize = new System.Drawing.Size(857, 495);
            this.ContextMenuStrip = this.contextMenuStripMain;
            this.Controls.Add(this.toolStripMain);
            this.Controls.Add(this.menuStripMain);
            this.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(100, 100);
            this.MainMenuStrip = this.menuStripMain;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormMain";
            this.Text = "Администратор";
            this.menuStripMain.ResumeLayout(false);
            this.menuStripMain.PerformLayout();
            this.contextMenuStripMain.ResumeLayout(false);
            this.toolStripMain.ResumeLayout(false);
            this.toolStripMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStripMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справочникToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem всеКнигиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пользователиToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripMain;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem1;
        private System.Windows.Forms.ToolStrip toolStripMain;
        private System.Windows.Forms.ToolStripButton выходtoolStripButton;
        private System.Windows.Forms.ToolStripButton опрограммеtoolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem справочникToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem всеКнигиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem пользователиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripButton книгиtoolStripButton;
        private System.Windows.Forms.ToolStripButton пользователиtoolStripButton;
        private System.Windows.Forms.ToolStripMenuItem книгаВЗаказеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заказToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripMenuItem книгаВЗаказеToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem заказToolStripMenuItem1;
    }
}

