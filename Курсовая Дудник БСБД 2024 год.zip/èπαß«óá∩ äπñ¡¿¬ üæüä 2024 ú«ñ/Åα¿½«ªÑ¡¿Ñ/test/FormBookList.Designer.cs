﻿namespace test
{
    partial class FormBookList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label iD_bookLabel;
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label genreLabel;
            System.Windows.Forms.Label publisherLabel;
            System.Windows.Forms.Label release_yearLabel;
            System.Windows.Forms.Label weightLabel;
            System.Windows.Forms.Label languageLabel;
            System.Windows.Forms.Label iSBNLabel;
            System.Windows.Forms.Label vendorLabel;
            System.Windows.Forms.Label age_limitLabel;
            System.Windows.Forms.Label priceLabel;
            System.Windows.Forms.Label quantity_in_stockLabel;
            System.Windows.Forms.Label authorsLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBookList));
            this.online_book_shopDataSet = new test.online_book_shopDataSet();
            this.bookBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bookTableAdapter = new test.online_book_shopDataSetTableAdapters.bookTableAdapter();
            this.tableAdapterManager = new test.online_book_shopDataSetTableAdapters.TableAdapterManager();
            this.bookBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.iD_bookTextBox = new System.Windows.Forms.TextBox();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.genreTextBox = new System.Windows.Forms.TextBox();
            this.publisherTextBox = new System.Windows.Forms.TextBox();
            this.release_yearTextBox = new System.Windows.Forms.TextBox();
            this.weightTextBox = new System.Windows.Forms.TextBox();
            this.languageTextBox = new System.Windows.Forms.TextBox();
            this.iSBNTextBox = new System.Windows.Forms.TextBox();
            this.vendorTextBox = new System.Windows.Forms.TextBox();
            this.age_limitTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.quantity_in_stockTextBox = new System.Windows.Forms.TextBox();
            this.authorsTextBox = new System.Windows.Forms.TextBox();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bookBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            iD_bookLabel = new System.Windows.Forms.Label();
            nameLabel = new System.Windows.Forms.Label();
            genreLabel = new System.Windows.Forms.Label();
            publisherLabel = new System.Windows.Forms.Label();
            release_yearLabel = new System.Windows.Forms.Label();
            weightLabel = new System.Windows.Forms.Label();
            languageLabel = new System.Windows.Forms.Label();
            iSBNLabel = new System.Windows.Forms.Label();
            vendorLabel = new System.Windows.Forms.Label();
            age_limitLabel = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            quantity_in_stockLabel = new System.Windows.Forms.Label();
            authorsLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.online_book_shopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingNavigator)).BeginInit();
            this.bookBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // online_book_shopDataSet
            // 
            this.online_book_shopDataSet.DataSetName = "online_book_shopDataSet";
            this.online_book_shopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bookBindingSource
            // 
            this.bookBindingSource.DataMember = "book";
            this.bookBindingSource.DataSource = this.online_book_shopDataSet;
            // 
            // bookTableAdapter
            // 
            this.bookTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.book_in_orderTableAdapter = null;
            this.tableAdapterManager.bookTableAdapter = this.bookTableAdapter;
            this.tableAdapterManager.customerTableAdapter = null;
            this.tableAdapterManager.order_TableAdapter = null;
            this.tableAdapterManager.UpdateOrder = test.online_book_shopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // bookBindingNavigator
            // 
            this.bookBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bookBindingNavigator.BindingSource = this.bookBindingSource;
            this.bookBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.bookBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bookBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bookBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.bookBindingNavigatorSaveItem});
            this.bookBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.bookBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bookBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bookBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bookBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bookBindingNavigator.Name = "bookBindingNavigator";
            this.bookBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.bookBindingNavigator.Size = new System.Drawing.Size(800, 31);
            this.bookBindingNavigator.TabIndex = 0;
            this.bookBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 28);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // iD_bookLabel
            // 
            iD_bookLabel.AutoSize = true;
            iD_bookLabel.Location = new System.Drawing.Point(41, 47);
            iD_bookLabel.Name = "iD_bookLabel";
            iD_bookLabel.Size = new System.Drawing.Size(63, 16);
            iD_bookLabel.TabIndex = 1;
            iD_bookLabel.Text = "ID книги:";
            // 
            // iD_bookTextBox
            // 
            this.iD_bookTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "ID_book", true));
            this.iD_bookTextBox.Location = new System.Drawing.Point(223, 44);
            this.iD_bookTextBox.Name = "iD_bookTextBox";
            this.iD_bookTextBox.Size = new System.Drawing.Size(262, 22);
            this.iD_bookTextBox.TabIndex = 2;
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(41, 75);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(76, 16);
            nameLabel.TabIndex = 3;
            nameLabel.Text = "Название:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "name", true));
            this.nameTextBox.Location = new System.Drawing.Point(223, 72);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(262, 22);
            this.nameTextBox.TabIndex = 4;
            // 
            // genreLabel
            // 
            genreLabel.AutoSize = true;
            genreLabel.Location = new System.Drawing.Point(41, 103);
            genreLabel.Name = "genreLabel";
            genreLabel.Size = new System.Drawing.Size(47, 16);
            genreLabel.TabIndex = 5;
            genreLabel.Text = "Жанр:";
            // 
            // genreTextBox
            // 
            this.genreTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "genre", true));
            this.genreTextBox.Location = new System.Drawing.Point(223, 100);
            this.genreTextBox.Name = "genreTextBox";
            this.genreTextBox.Size = new System.Drawing.Size(262, 22);
            this.genreTextBox.TabIndex = 6;
            // 
            // publisherLabel
            // 
            publisherLabel.AutoSize = true;
            publisherLabel.Location = new System.Drawing.Point(41, 131);
            publisherLabel.Name = "publisherLabel";
            publisherLabel.Size = new System.Drawing.Size(74, 16);
            publisherLabel.TabIndex = 7;
            publisherLabel.Text = "Издатель:";
            // 
            // publisherTextBox
            // 
            this.publisherTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "publisher", true));
            this.publisherTextBox.Location = new System.Drawing.Point(223, 128);
            this.publisherTextBox.Name = "publisherTextBox";
            this.publisherTextBox.Size = new System.Drawing.Size(262, 22);
            this.publisherTextBox.TabIndex = 8;
            // 
            // release_yearLabel
            // 
            release_yearLabel.AutoSize = true;
            release_yearLabel.Location = new System.Drawing.Point(41, 159);
            release_yearLabel.Name = "release_yearLabel";
            release_yearLabel.Size = new System.Drawing.Size(91, 16);
            release_yearLabel.TabIndex = 9;
            release_yearLabel.Text = "Год выпуска:";
            // 
            // release_yearTextBox
            // 
            this.release_yearTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "release_year", true));
            this.release_yearTextBox.Location = new System.Drawing.Point(223, 156);
            this.release_yearTextBox.Name = "release_yearTextBox";
            this.release_yearTextBox.Size = new System.Drawing.Size(262, 22);
            this.release_yearTextBox.TabIndex = 10;
            // 
            // weightLabel
            // 
            weightLabel.AutoSize = true;
            weightLabel.Location = new System.Drawing.Point(41, 187);
            weightLabel.Name = "weightLabel";
            weightLabel.Size = new System.Drawing.Size(34, 16);
            weightLabel.TabIndex = 11;
            weightLabel.Text = "Вес:";
            // 
            // weightTextBox
            // 
            this.weightTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "weight", true));
            this.weightTextBox.Location = new System.Drawing.Point(223, 184);
            this.weightTextBox.Name = "weightTextBox";
            this.weightTextBox.Size = new System.Drawing.Size(262, 22);
            this.weightTextBox.TabIndex = 12;
            // 
            // languageLabel
            // 
            languageLabel.AutoSize = true;
            languageLabel.Location = new System.Drawing.Point(41, 215);
            languageLabel.Name = "languageLabel";
            languageLabel.Size = new System.Drawing.Size(44, 16);
            languageLabel.TabIndex = 13;
            languageLabel.Text = "Язык:";
            // 
            // languageTextBox
            // 
            this.languageTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "language", true));
            this.languageTextBox.Location = new System.Drawing.Point(223, 212);
            this.languageTextBox.Name = "languageTextBox";
            this.languageTextBox.Size = new System.Drawing.Size(262, 22);
            this.languageTextBox.TabIndex = 14;
            // 
            // iSBNLabel
            // 
            iSBNLabel.AutoSize = true;
            iSBNLabel.Location = new System.Drawing.Point(41, 243);
            iSBNLabel.Name = "iSBNLabel";
            iSBNLabel.Size = new System.Drawing.Size(41, 16);
            iSBNLabel.TabIndex = 15;
            iSBNLabel.Text = "ISBN:";
            // 
            // iSBNTextBox
            // 
            this.iSBNTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "ISBN", true));
            this.iSBNTextBox.Location = new System.Drawing.Point(223, 240);
            this.iSBNTextBox.Name = "iSBNTextBox";
            this.iSBNTextBox.Size = new System.Drawing.Size(262, 22);
            this.iSBNTextBox.TabIndex = 16;
            // 
            // vendorLabel
            // 
            vendorLabel.AutoSize = true;
            vendorLabel.Location = new System.Drawing.Point(41, 271);
            vendorLabel.Name = "vendorLabel";
            vendorLabel.Size = new System.Drawing.Size(82, 16);
            vendorLabel.TabIndex = 17;
            vendorLabel.Text = "Поставщик:";
            // 
            // vendorTextBox
            // 
            this.vendorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "vendor", true));
            this.vendorTextBox.Location = new System.Drawing.Point(223, 268);
            this.vendorTextBox.Name = "vendorTextBox";
            this.vendorTextBox.Size = new System.Drawing.Size(262, 22);
            this.vendorTextBox.TabIndex = 18;
            // 
            // age_limitLabel
            // 
            age_limitLabel.AutoSize = true;
            age_limitLabel.Location = new System.Drawing.Point(39, 299);
            age_limitLabel.Name = "age_limitLabel";
            age_limitLabel.Size = new System.Drawing.Size(178, 16);
            age_limitLabel.TabIndex = 19;
            age_limitLabel.Text = "Возрастное ограничение:";
            // 
            // age_limitTextBox
            // 
            this.age_limitTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "age_limit", true));
            this.age_limitTextBox.Location = new System.Drawing.Point(223, 296);
            this.age_limitTextBox.Name = "age_limitTextBox";
            this.age_limitTextBox.Size = new System.Drawing.Size(262, 22);
            this.age_limitTextBox.TabIndex = 20;
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Location = new System.Drawing.Point(41, 327);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(43, 16);
            priceLabel.TabIndex = 21;
            priceLabel.Text = "Цена:";
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "price", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "C2"));
            this.priceTextBox.Location = new System.Drawing.Point(223, 324);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(262, 22);
            this.priceTextBox.TabIndex = 22;
            // 
            // quantity_in_stockLabel
            // 
            quantity_in_stockLabel.AutoSize = true;
            quantity_in_stockLabel.Location = new System.Drawing.Point(41, 355);
            quantity_in_stockLabel.Name = "quantity_in_stockLabel";
            quantity_in_stockLabel.Size = new System.Drawing.Size(97, 16);
            quantity_in_stockLabel.TabIndex = 23;
            quantity_in_stockLabel.Text = "Кл. на складе:";
            // 
            // quantity_in_stockTextBox
            // 
            this.quantity_in_stockTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "quantity_in_stock", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "N0"));
            this.quantity_in_stockTextBox.Location = new System.Drawing.Point(223, 352);
            this.quantity_in_stockTextBox.Name = "quantity_in_stockTextBox";
            this.quantity_in_stockTextBox.Size = new System.Drawing.Size(262, 22);
            this.quantity_in_stockTextBox.TabIndex = 24;
            // 
            // authorsLabel
            // 
            authorsLabel.AutoSize = true;
            authorsLabel.Location = new System.Drawing.Point(41, 383);
            authorsLabel.Name = "authorsLabel";
            authorsLabel.Size = new System.Drawing.Size(50, 16);
            authorsLabel.TabIndex = 25;
            authorsLabel.Text = "Автор:";
            // 
            // authorsTextBox
            // 
            this.authorsTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bookBindingSource, "authors", true, System.Windows.Forms.DataSourceUpdateMode.OnValidation, null, "d"));
            this.authorsTextBox.Location = new System.Drawing.Point(223, 380);
            this.authorsTextBox.Name = "authorsTextBox";
            this.authorsTextBox.Size = new System.Drawing.Size(262, 22);
            this.authorsTextBox.TabIndex = 26;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bookBindingNavigatorSaveItem
            // 
            this.bookBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bookBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("bookBindingNavigatorSaveItem.Image")));
            this.bookBindingNavigatorSaveItem.Name = "bookBindingNavigatorSaveItem";
            this.bookBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 28);
            this.bookBindingNavigatorSaveItem.Text = "Сохранить данные";
            this.bookBindingNavigatorSaveItem.Click += new System.EventHandler(this.bookBindingNavigatorSaveItem_Click);
            // 
            // FormBookList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.CadetBlue;
            this.ClientSize = new System.Drawing.Size(800, 457);
            this.Controls.Add(iD_bookLabel);
            this.Controls.Add(this.iD_bookTextBox);
            this.Controls.Add(nameLabel);
            this.Controls.Add(this.nameTextBox);
            this.Controls.Add(genreLabel);
            this.Controls.Add(this.genreTextBox);
            this.Controls.Add(publisherLabel);
            this.Controls.Add(this.publisherTextBox);
            this.Controls.Add(release_yearLabel);
            this.Controls.Add(this.release_yearTextBox);
            this.Controls.Add(weightLabel);
            this.Controls.Add(this.weightTextBox);
            this.Controls.Add(languageLabel);
            this.Controls.Add(this.languageTextBox);
            this.Controls.Add(iSBNLabel);
            this.Controls.Add(this.iSBNTextBox);
            this.Controls.Add(vendorLabel);
            this.Controls.Add(this.vendorTextBox);
            this.Controls.Add(age_limitLabel);
            this.Controls.Add(this.age_limitTextBox);
            this.Controls.Add(priceLabel);
            this.Controls.Add(this.priceTextBox);
            this.Controls.Add(quantity_in_stockLabel);
            this.Controls.Add(this.quantity_in_stockTextBox);
            this.Controls.Add(authorsLabel);
            this.Controls.Add(this.authorsTextBox);
            this.Controls.Add(this.bookBindingNavigator);
            this.Name = "FormBookList";
            this.Text = "Список книг";
            this.Load += new System.EventHandler(this.FormBookList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.online_book_shopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bookBindingNavigator)).EndInit();
            this.bookBindingNavigator.ResumeLayout(false);
            this.bookBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private online_book_shopDataSet online_book_shopDataSet;
        private System.Windows.Forms.BindingSource bookBindingSource;
        private online_book_shopDataSetTableAdapters.bookTableAdapter bookTableAdapter;
        private online_book_shopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator bookBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton bookBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox iD_bookTextBox;
        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox genreTextBox;
        private System.Windows.Forms.TextBox publisherTextBox;
        private System.Windows.Forms.TextBox release_yearTextBox;
        private System.Windows.Forms.TextBox weightTextBox;
        private System.Windows.Forms.TextBox languageTextBox;
        private System.Windows.Forms.TextBox iSBNTextBox;
        private System.Windows.Forms.TextBox vendorTextBox;
        private System.Windows.Forms.TextBox age_limitTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.TextBox quantity_in_stockTextBox;
        private System.Windows.Forms.TextBox authorsTextBox;
    }
}