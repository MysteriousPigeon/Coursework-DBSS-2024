﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class FormBookInOrder : Form
    {
        public FormBookInOrder()
        {
            InitializeComponent();
        }

        private void book_in_orderBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.book_in_orderBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.online_book_shopDataSet);

        }

        private void FormBookInOrder_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "online_book_shopDataSet.book_in_order". При необходимости она может быть перемещена или удалена.
            this.book_in_orderTableAdapter.Fill(this.online_book_shopDataSet.book_in_order);

        }

        private static FormBookInOrder b;
        public static FormBookInOrder fb
        {
            get
            {
                if (b == null || b.IsDisposed) b = new FormBookInOrder();
                return b;
            }
        }
        public void ShowForm()
        {
            Show();
            Activate();
        }
    }
}
