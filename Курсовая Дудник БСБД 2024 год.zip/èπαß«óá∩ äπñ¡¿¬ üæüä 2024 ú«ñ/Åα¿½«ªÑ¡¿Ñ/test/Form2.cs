﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {



        }
        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string login = Convert.ToString(loginField.Text);
            string pass = Convert.ToString(passField.Text);
            string conn = $"Data Source=desktop-7evsgqb;Initial Catalog=online_book_shop;USER Id={login};Password={pass}";
            SqlConnection conn2 = new SqlConnection(conn);
            try
            {
                conn2.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Неправильный логин или пароль");
            }
            if (conn2.State == ConnectionState.Open)
            {
                MessageBox.Show("Вход произошел успешно");
                this.Hide();
                if (login == "adminka" || login == "adminka")
                {
                    // Открываем форму для администратора
                    FormMain Form1 = new FormMain();
                    Form1.Show();
                }
                /*else
                {
                    Form1.fs.ShowForm();
                }*/
            }
        }
    }
}