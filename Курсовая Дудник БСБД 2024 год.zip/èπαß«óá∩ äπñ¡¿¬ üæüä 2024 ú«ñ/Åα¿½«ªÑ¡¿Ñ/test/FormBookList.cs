﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class FormBookList : Form
    {
        public FormBookList()
        {
            InitializeComponent();
        }

        private void bookBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.bookBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.online_book_shopDataSet);

        }

        private static FormBookList f;

        public static FormBookList fd
        {
            get
            {
                if ( f== null || f.IsDisposed) f = new FormBookList();
                return f;
            }
        }

        public void ShowForm()
        {
            Show();
            Activate();
        }

        private void FormBookList_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "online_book_shopDataSet.book". При необходимости она может быть перемещена или удалена.
            this.bookTableAdapter.Fill(this.online_book_shopDataSet.book);

        }
    }
}
