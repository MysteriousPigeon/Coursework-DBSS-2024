﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void оПрограммеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(С) ТУСУР, КИБЭВС, Дудник Дарья Андреевна, 711-2, 2024", "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void выходToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void оПрограммеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(С) ТУСУР, КИБЭВС, Дудник Дарья Андреевна, 711-2, 2024", "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void выходtoolStripButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void опрограммеtoolStripButton2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("(С) ТУСУР, КИБЭВС, Дудник Дарья Андреевна, 711-2, 2024", "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void всеКнигиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBookList.fd.ShowForm();
        }

        private void пользователиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUserList.fw.ShowForm();
        }

        private void книгиtoolStripButton_Click(object sender, EventArgs e)
        {
            FormBookList.fd.ShowForm();
        }

        private void пользователиtoolStripButton_Click(object sender, EventArgs e)
        {
            FormUserList.fw.ShowForm();
        }

        private void всеКнигиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormBookList.fd.ShowForm();
        }

        private void пользователиToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormUserList.fw.ShowForm();
        }

       

        private void toolStripMain_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void книгаВЗаказеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormBookInOrder.fb.ShowForm();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            FormBookInOrder.fb.ShowForm();
        }

        private void книгаВЗаказеToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormBookInOrder.fb.ShowForm();
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            FormOrder.fo.ShowForm();
        }

        private void заказToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOrder.fo.ShowForm();
        }

        private void заказToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FormOrder.fo.ShowForm();
        }
    }
}
